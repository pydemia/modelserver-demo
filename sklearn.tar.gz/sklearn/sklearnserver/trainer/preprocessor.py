__all__ = ['prep_func']

def prep_func(inputs):
    return inputs
